package com.example.closetvalue;

public enum GarmentTypes {
    TOP,
    BOTTOM,
    SHOES,
    OTHER
}
